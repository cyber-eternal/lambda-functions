const a = 5;
const c = 50;